Oppgaver:

1. Endre utskriften slik at den ligner på det i bilde ttt.png. Merk at rader og kolloner er nummerert fra 1 til 3 (ikke 0 til 2).
2. Spillet gjenkjenner ikke når noen vinner på diagonalene. Skriv koden som skal til for at man kan vinne på diagonalen.
3. Spilleren skal kunne skrive in r for å starte spillet på nytt.
4. Spilleren skal kunne skrive in q for å avslutte spillet før det er ferdig.
5. Dersom man skriver inn noe annet en kolone,rad så kræsjer spillet. Fiks det slik at det ikke fører til kræsj, men at spilleren må skrive inn på nytt (tips [isNaN](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/isNaN))
6. Isteden for at spillerene skal hete Spiller 1 og Spiller 2 (som i oppgave 4), la spillerene skrive inn sine navn. 
7. Refactor koden (pass spesielt på å ikke ha magiske strings eller tall i koden).

Extra credits:

* Vis grafisk (eks fargeleg bakgrunn) på rad/kolone/diagonal somm er vinner resultatet.
* (vanskelig) Isteden for at spilleren skriver inn en kordinat, la spilleren navigere seg rundt på brettet for å hvelge hvor å sette merket (Tips ANSI hjelper deg med dette)..